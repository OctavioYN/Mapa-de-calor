﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Net;
using System.Data.OleDb;
using MySql.Data.MySqlClient;
using MySql.Data.Types;
using System.Threading;

namespace Dashboard
{
    public partial class MapaCalor : Form
    {
        //MySqlConnection conexionMysql = new MySqlConnection("server=127.0.0.1;database=db_mapa_calor;uid=root;pwd=cyber123");
        MySqlConnection conexionMysql = new MySqlConnection("server=127.0.0.1;database=db_mapa_calor;uid=root;pwd=xmy8196");
        public MapaCalor()
        {
            InitializeComponent();

        }




        DataView ImportarDatos(string nombrearchivo) //COMO PARAMETROS OBTENEMOS EL NOMBRE DEL ARCHIVO A IMPORTAR
        {
            //UTILIZAMOS 12.0 DEPENDIENDO DE LA VERSION DEL EXCEL, EN CASO DE QUE LA VERSIÓN QUE TIENES ES INFERIOR AL DEL 2013, CAMBIAR A EXCEL 8.0 Y EN VEZ DE
            //ACE.OLEDB.12.0 UTILIZAR LO SIGUIENTE (Jet.Oledb.4.0)

            string conexion = string.Format("Provider = Microsoft.Jet.OLEDB.4.0; Data Source = {0}; Extended Properties = 'Excel 8.0;'", nombrearchivo);

            OleDbConnection conector = new OleDbConnection(conexion);

            conector.Open();

            string strQuery = "";
            string SpreadSheetName = "";
            int workSheetNumber = 0;

            DataTable ExcelSheets = conector.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            SpreadSheetName = ExcelSheets.Rows[workSheetNumber]["TABLE_NAME"].ToString();

            //DEPENDIENDO DEL NOMBRE QUE TIENE LA PESTAÑA EN TU ARCHIVO EXCEL COLOCAR DENTRO DE LOS []
            strQuery = "select * from [" + SpreadSheetName + "] ";
            MessageBox.Show(SpreadSheetName);
            OleDbCommand consulta = new OleDbCommand(strQuery, conector);

            OleDbDataAdapter adaptador = new OleDbDataAdapter
            {
                SelectCommand = consulta
            };

            DataSet ds = new DataSet();

            adaptador.Fill(ds);

            conector.Close();

            return ds.Tables[0].DefaultView;

        }


        public void insertaraBd()
        {
            MySqlCommand agregar = new MySqlCommand("insert into tblinfoaldia (No,JOBNAME,FOLDER,APPLICATION,SUB_APPLICATION,RUN_AS,ORDERID,ODATE,START_TIME,ET,HOST,STATUS)" +
                    " VALUES (?No,?JOBNAME,?FOLDER,?APPLICATION,?SUB_APPLICATION,?RUN_AS,?ORDERID,?ODATE,?START_TIME,?ET,?HOST,?STATUS)", conexionMysql);
            conexionMysql.Open();
            try
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    agregar.Parameters.Clear();
                    agregar.Parameters.AddWithValue("@No", Convert.ToString(row.Cells["No#"].Value));
                    agregar.Parameters.AddWithValue("@JOBNAME", Convert.ToString(row.Cells["JOBNAME"].Value));
                    agregar.Parameters.AddWithValue("@FOLDER", Convert.ToString(row.Cells["FOLDER"].Value));
                    agregar.Parameters.AddWithValue("@APPLICATION", Convert.ToString(row.Cells["APPLICATION"].Value));
                    agregar.Parameters.AddWithValue("@SUB_APPLICATION", Convert.ToString(row.Cells["SUB-APPLICATION"].Value));
                    agregar.Parameters.AddWithValue("@RUN_AS", Convert.ToString(row.Cells["RUN AS"].Value));
                    agregar.Parameters.AddWithValue("@ORDERID", Convert.ToString(row.Cells["ORDERID"].Value));
                    agregar.Parameters.AddWithValue("@ODATE", Convert.ToString(row.Cells["ODATE"].Value));
                    agregar.Parameters.AddWithValue("@START_TIME", Convert.ToDateTime(row.Cells["START TIME"].Value));
                    agregar.Parameters.AddWithValue("@ET", Convert.ToDateTime(row.Cells["END TIME"].Value));
                    agregar.Parameters.AddWithValue("@HOST", Convert.ToString(row.Cells["HOST"].Value));
                    agregar.Parameters.AddWithValue("@STATUS", Convert.ToString(row.Cells["STATUS"].Value));
                    agregar.CommandTimeout = 300;
                    agregar.ExecuteNonQuery();
                }
                  MessageBox.Show("Datos aregados");
                conexionMysql.Close();
            }
            catch (MySqlException MyException)
            {
                Console.WriteLine("Error al insertar : " + MyException.Number + "  " + MyException.Message);
                //MessageBox.Show("Error al insertar "+ );
                conexionMysql.Close();
            }

        }



        private void btnAgrega_Click(object sender, EventArgs e)
        {
            btnDescargar.Visible = false;
            dataGridView1.DataSource = "";
            dataGridView1.Columns.Clear();

            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                //DE ESTA MANERA FILTRAMOS TODOS LOS ARCHIVOS EXCEL EN EL NAVEGADOR DE ARCHIVOS
                Filter = "Excel | *.xls;*.xlsx;",

                //AQUÍ INDICAMOS QUE NOMBRE TENDRÁ EL NAVEGADOR DE ARCHIVOS COMO TITULO
                Title = "Seleccionar Archivo ARCHIVO 97-2003 GRACIAS"
            };

            //EN CASO DE SELECCIONAR EL ARCHIVO, ENTONCES PROCEDEMOS A ABRIR EL ARCHIVO CORRESPONDIENTE

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                dataGridView1.DataSource = ImportarDatos(openFileDialog.FileName);
                dataGridView1.RowHeadersVisible = false;
                dataGridView1.Visible = true;

            }
            btnAgrega.Visible = false;
            btnMapa.Visible = true;
            btnMostrarMapa.Visible = false;
        }

        private void btnMapa_Click(object sender, EventArgs e)
        {
            btnMapa.Visible = false;

            insertaraBd();

            dataGridView1.DataSource = "";
            dataGridView1.Columns.Clear();

            //pa_crear_mapa();


            dataGridView1.DataSource = consultarMapa();
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.Visible = true;
            
            btnDescargar.Visible = true;
            btnMapa.Visible = false;
            btnAgrega.Visible = true;
            btnMostrarMapa.Visible = false;
        }


        public void pa_crear_mapa()
        {

            DateTime fecha = DateTime.Now;

            string mes = fecha.ToString("MM");
            string dia = fecha.ToString("dd");
            string a = fecha.ToString("yy");


            try
            {
                MessageBox.Show("El mes es "+ mes);
                MySqlCommand myCommand = new MySqlCommand("call pa_crear_mapa("+mes+")", conexionMysql);
                conexionMysql.Open();
                myCommand.ExecuteNonQuery();
                MessageBox.Show("Mapa creado");
            }
            catch (MySqlException MyException)
            {
                Console.WriteLine("Eror en el store procedure: MySQL code: " + MyException.Number + "  " + MyException.Message);
            }
            conexionMysql.Close();
      

        }

        private DataTable consultarMapa()
        {
            DataTable dt = new DataTable();


            conexionMysql.Open();
            string consultarMapa = "Select*from tblMapaCalor";
            MySqlCommand cmd = new MySqlCommand(consultarMapa, conexionMysql);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            conexionMysql.Close();
            return dt;
        }

        private void btnMostrarMapa_Click(object sender, EventArgs e)
        {


            

            dataGridView1.Visible = true;
            dataGridView1.DataSource = consultarMapa();
            dataGridView1.RowHeadersVisible = false;
            btnDescargar.Visible = true;
            dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


        }

        private void btnDescargar_Click(object sender, EventArgs e)
        {
            SaveFileDialog fichero = new SaveFileDialog();
            fichero.Filter = "Excel (*.xls)|*.xls";
            if (fichero.ShowDialog() == DialogResult.OK)
            {
                Microsoft.Office.Interop.Excel.Application aplicacion;
                Microsoft.Office.Interop.Excel.Workbook libros_trabajo;
                Microsoft.Office.Interop.Excel.Worksheet hoja_trabajo;
                aplicacion = new Microsoft.Office.Interop.Excel.Application();
                libros_trabajo = aplicacion.Workbooks.Add();
                hoja_trabajo = (Microsoft.Office.Interop.Excel.Worksheet)libros_trabajo.Worksheets.get_Item(1);
                //Recorremos el DataGridView rellenando la hoja de trabajo

                /*for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        hoja_trabajo.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }*/

                int valorFila = 0;
                for (int i = 1; i <= this.dataGridView1.Columns.Count; i++)
                {
                    hoja_trabajo.Cells[1, i] = this.dataGridView1.Columns[i - 1].HeaderText;

                }
                valorFila = valorFila + 1;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        if ((dataGridView1.Rows[i].Cells[j].Value == null) == false)
                        {

                            hoja_trabajo.Cells[valorFila + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();


                        }
                    }
                    valorFila++;
                }



                libros_trabajo.SaveAs(fichero.FileName,
                    Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal);
                libros_trabajo.Close(true);
                aplicacion.Quit();
                MessageBox.Show("Excel generado");
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            try
            {


                if (this.dataGridView1.Columns[e.ColumnIndex].Name == "Promedio")
                {
                    if (e.Value != null)
                    {
                        if (e.Value.GetType() != typeof(System.DBNull))
                        {
                            //Promedio mayor a 98
                            if (Convert.ToInt32(e.Value) >= 98.5)
                            {
                                e.CellStyle.BackColor = Color.DarkBlue;
                                e.CellStyle.ForeColor = Color.White;

                            }
                            //Stock menor a 10
                            if (Convert.ToInt32(e.Value) >= 97 && Convert.ToInt32(e.Value) < 98.5)
                            {
                                e.CellStyle.BackColor = Color.DarkGreen;
                                e.CellStyle.ForeColor = Color.White;
                            }
                            //Stock menor a 10
                            if (Convert.ToInt32(e.Value) > 95 && Convert.ToInt32(e.Value) < 97)
                            {
                                e.CellStyle.BackColor = Color.Yellow;
                                e.CellStyle.ForeColor = Color.Black;
                            }
                            //Stock menor a 10
                            if (Convert.ToInt32(e.Value) <= 95)
                            {
                                e.CellStyle.BackColor = Color.Red;
                                e.CellStyle.ForeColor = Color.White;
                            }

                        }
                    }
                    e.Value = e.Value + "%";
                }
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex);
             
            }

            
        }
    }
}
