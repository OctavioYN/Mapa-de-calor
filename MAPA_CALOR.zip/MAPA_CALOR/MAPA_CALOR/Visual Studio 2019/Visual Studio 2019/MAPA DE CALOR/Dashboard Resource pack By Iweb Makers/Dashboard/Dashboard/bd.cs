﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;


namespace Dashboard
{
    public class bd
    {
        OracleConnection con;
        //Datos de conexión para no usar tnsnames.ora
        string connectionString = "DATA SOURCE= (DESCRIPTION =" +
         "(ADDRESS_LIST =" +
         "(ADDRESS = (COMMUNITY = tcp.world)(PROTOCOL = TCP)(Host = 150.100.128.23)(Port = 3200)))" +
         "(CONNECT_DATA =(service_name= bifbpmx1))) ; User Id=batch;Password=batch12; ";

        // public OracleConnection conexion()
        //{
        //     string mensaje;
        //     try
        //     {

        //         //Datos de conexión para no usar tnsnames.ora
        //         string constr = "DATA SOURCE= (DESCRIPTION =" +
        //             "(ADDRESS_LIST =" +
        //             "(ADDRESS = (COMMUNITY = tcp.world)(PROTOCOL = TCP)(Host = 150.100.43.146)(Port = 1521)))" +
        //             "(CONNECT_DATA =(SID = bifbpmx12))) ; User Id=batch;Password=batch12; ";
        //         con = new OracleConnection(constr);
        //         con.Open();

        //         mensaje=("Conectado a servidor Oracle, versión: " + con.ServerVersion);
        //         con.Dispose();
        //     }
        //     catch (Exception ex)
        //     {
        //         mensaje=("Error al conectar a Oracle: " + ex);
        //     }
        //     return con;
        //}

        public int conteo(string query)
        {
            int count = 0;

            try
            {

                //"SELECT EmpNo, DeptNo FROM Scott.Emp"    
                string queryString = query;
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    OracleCommand command = new OracleCommand(queryString, connection);
                    connection.Open();
                    OracleDataReader reader = command.ExecuteReader();
                    try
                    {
                        while (reader.Read())
                        {
                            count = reader.GetInt32(0);
                            // Console.WriteLine(reader.GetString(0));
                            //Console.WriteLine(reader.GetInt32(0) + ", " + reader.GetInt32(1));
                        }

                    }
                    finally
                    {
                        // always call Close when done reading.
                        reader.Close();
                        connection.Close();
                    }

                }
            }catch (Exception ex)
            {
                Console.WriteLine("Error al conectar a Oracle: " + ex);
            }
            return count;
        }


        public DataTable GetConsultasTablas(String query)
        {


            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                List<String> LDptos = new List<string>();
                string sqlQuery = query;
                OracleCommand cmd = new OracleCommand(sqlQuery, connection);
                cmd.CommandType = CommandType.Text;
                DataTable dt = new DataTable();
                OracleDataAdapter da = new OracleDataAdapter(cmd);
                try
                {
                    connection.Open();
                    da.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }






    }
}
