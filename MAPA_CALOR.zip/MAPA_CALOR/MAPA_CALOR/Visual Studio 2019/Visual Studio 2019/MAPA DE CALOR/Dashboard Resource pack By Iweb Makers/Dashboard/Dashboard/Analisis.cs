﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard
{
    public partial class Analisis : Form
    {
        public Analisis()
        {
            InitializeComponent();
            llenarTabla();
        }

        public void llenarTabla() {

            bd obj_consulta = new bd();



            DataTable sesiones = new DataTable();
            try
            {
                sesiones = obj_consulta.GetConsultasTablas("select SID, SERIAL#, USERNAME, STATUS, " +
                    "OSUSER, PROCESS, MACHINE, SQL_EXEC_START, " +
                    "LOGON_TIME, BLOCKING_SESSION_STATUS, BLOCKING_SESSION, STATE" +
                    " from v$session" +
                    " where username = 'BATCH'");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.Close();
            }

            dataGrid.DataSource = sesiones;
            dataGrid.RowHeadersVisible = false;
        }

    }



}
