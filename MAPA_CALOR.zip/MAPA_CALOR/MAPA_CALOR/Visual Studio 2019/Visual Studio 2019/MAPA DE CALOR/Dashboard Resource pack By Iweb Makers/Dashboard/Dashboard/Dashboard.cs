﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            metodos();
        }


        public void metodos() {

            String fecha="";
            //fecha = DateTime.Now.ToString("dd/MMMM/yyyy hh:mm:ss");

            lblDetalleFecha1.Text = fecha;
            lblDetalleFecha2.Text = fecha;
            lblDetalleFecha3.Text = fecha;
            lblDetalleFecha4.Text = fecha;
            //MessageBox.Show("Abriendo Dashboard");
            bd con = new bd();
            //MessageBox.Show(con.conexion().ToString());

            
            lblNoActivas.Text = con.conteo(" select count(*) from V$SESSION WHERE USERNAME IN('DBSBIF', 'BATCH') AND STATUS = 'ACTIVE'").ToString();
            lblNoInactivas.Text = con.conteo(" select count(*) from V$SESSION WHERE USERNAME IN('DBSBIF', 'BATCH') AND STATUS = 'INACTIVE'").ToString();

            lblNoBatch.Text = con.conteo("select count(*) from V$SESSION WHERE USERNAME IN('BATCH')").ToString();
            lblNoDbsbif.Text = con.conteo("select count(*) from V$SESSION WHERE USERNAME IN ('DBSBIF')").ToString();

        }
       
    }
}
