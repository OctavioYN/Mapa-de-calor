﻿namespace Dashboard
{
    partial class GeneraDashboards
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.CheckboxD = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.CheckboxS = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.CheckboxV = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.CheckboxJ = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.CheckboxMi = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.CheckboxMa = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.CheckboxL = new Bunifu.Framework.UI.BunifuCheckbox();
            this.lblTodos = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.CheckboxTodos = new Bunifu.Framework.UI.BunifuCheckbox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCopiar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.lvFics = new System.Windows.Forms.ListView();
            this.ColumnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LabelInfo = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnExaminaDestino = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnExaminaOrigen = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtDestino = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtOrigen = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.rbtRetenciones = new System.Windows.Forms.RadioButton();
            this.rbtDisolucion = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnGenera = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1077, 24);
            this.panel2.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 572);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1077, 24);
            this.panel1.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(1053, 24);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(24, 548);
            this.panel3.TabIndex = 12;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 24);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(24, 548);
            this.panel4.TabIndex = 13;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bunifuCustomLabel7);
            this.groupBox1.Controls.Add(this.CheckboxD);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel6);
            this.groupBox1.Controls.Add(this.CheckboxS);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel5);
            this.groupBox1.Controls.Add(this.CheckboxV);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel4);
            this.groupBox1.Controls.Add(this.CheckboxJ);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel3);
            this.groupBox1.Controls.Add(this.CheckboxMi);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel2);
            this.groupBox1.Controls.Add(this.CheckboxMa);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel1);
            this.groupBox1.Controls.Add(this.CheckboxL);
            this.groupBox1.Controls.Add(this.lblTodos);
            this.groupBox1.Controls.Add(this.CheckboxTodos);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(30, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(240, 143);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dias de la Semana";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(168, 110);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(49, 13);
            this.bunifuCustomLabel7.TabIndex = 22;
            this.bunifuCustomLabel7.Text = "Domingo";
            // 
            // CheckboxD
            // 
            this.CheckboxD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxD.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxD.Checked = false;
            this.CheckboxD.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CheckboxD.ForeColor = System.Drawing.Color.White;
            this.CheckboxD.Location = new System.Drawing.Point(142, 110);
            this.CheckboxD.Name = "CheckboxD";
            this.CheckboxD.Size = new System.Drawing.Size(20, 20);
            this.CheckboxD.TabIndex = 21;
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(168, 88);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(44, 13);
            this.bunifuCustomLabel6.TabIndex = 20;
            this.bunifuCustomLabel6.Text = "Sabado";
            // 
            // CheckboxS
            // 
            this.CheckboxS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxS.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxS.Checked = false;
            this.CheckboxS.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CheckboxS.ForeColor = System.Drawing.Color.White;
            this.CheckboxS.Location = new System.Drawing.Point(142, 88);
            this.CheckboxS.Name = "CheckboxS";
            this.CheckboxS.Size = new System.Drawing.Size(20, 20);
            this.CheckboxS.TabIndex = 19;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(168, 65);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(42, 13);
            this.bunifuCustomLabel5.TabIndex = 18;
            this.bunifuCustomLabel5.Text = "Viernes";
            // 
            // CheckboxV
            // 
            this.CheckboxV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxV.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxV.Checked = false;
            this.CheckboxV.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CheckboxV.ForeColor = System.Drawing.Color.White;
            this.CheckboxV.Location = new System.Drawing.Point(142, 65);
            this.CheckboxV.Name = "CheckboxV";
            this.CheckboxV.Size = new System.Drawing.Size(20, 20);
            this.CheckboxV.TabIndex = 17;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(168, 39);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(41, 13);
            this.bunifuCustomLabel4.TabIndex = 16;
            this.bunifuCustomLabel4.Text = "Jueves";
            // 
            // CheckboxJ
            // 
            this.CheckboxJ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxJ.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxJ.Checked = false;
            this.CheckboxJ.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CheckboxJ.ForeColor = System.Drawing.Color.White;
            this.CheckboxJ.Location = new System.Drawing.Point(142, 39);
            this.CheckboxJ.Name = "CheckboxJ";
            this.CheckboxJ.Size = new System.Drawing.Size(20, 20);
            this.CheckboxJ.TabIndex = 15;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(32, 110);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(52, 13);
            this.bunifuCustomLabel3.TabIndex = 7;
            this.bunifuCustomLabel3.Text = "Miercoles";
            // 
            // CheckboxMi
            // 
            this.CheckboxMi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxMi.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxMi.Checked = false;
            this.CheckboxMi.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CheckboxMi.ForeColor = System.Drawing.Color.White;
            this.CheckboxMi.Location = new System.Drawing.Point(6, 110);
            this.CheckboxMi.Name = "CheckboxMi";
            this.CheckboxMi.Size = new System.Drawing.Size(20, 20);
            this.CheckboxMi.TabIndex = 6;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(32, 88);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(39, 13);
            this.bunifuCustomLabel2.TabIndex = 5;
            this.bunifuCustomLabel2.Text = "Martes";
            // 
            // CheckboxMa
            // 
            this.CheckboxMa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxMa.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxMa.Checked = false;
            this.CheckboxMa.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CheckboxMa.ForeColor = System.Drawing.Color.White;
            this.CheckboxMa.Location = new System.Drawing.Point(6, 88);
            this.CheckboxMa.Name = "CheckboxMa";
            this.CheckboxMa.Size = new System.Drawing.Size(20, 20);
            this.CheckboxMa.TabIndex = 4;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(32, 65);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(36, 13);
            this.bunifuCustomLabel1.TabIndex = 3;
            this.bunifuCustomLabel1.Text = "Lunes";
            // 
            // CheckboxL
            // 
            this.CheckboxL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxL.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxL.Checked = false;
            this.CheckboxL.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CheckboxL.ForeColor = System.Drawing.Color.White;
            this.CheckboxL.Location = new System.Drawing.Point(6, 65);
            this.CheckboxL.Name = "CheckboxL";
            this.CheckboxL.Size = new System.Drawing.Size(20, 20);
            this.CheckboxL.TabIndex = 2;
            // 
            // lblTodos
            // 
            this.lblTodos.AutoSize = true;
            this.lblTodos.Location = new System.Drawing.Point(32, 29);
            this.lblTodos.Name = "lblTodos";
            this.lblTodos.Size = new System.Drawing.Size(96, 13);
            this.lblTodos.TabIndex = 1;
            this.lblTodos.Text = "Seleccionar Todos";
            // 
            // CheckboxTodos
            // 
            this.CheckboxTodos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxTodos.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.CheckboxTodos.Checked = false;
            this.CheckboxTodos.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CheckboxTodos.ForeColor = System.Drawing.Color.White;
            this.CheckboxTodos.Location = new System.Drawing.Point(6, 29);
            this.CheckboxTodos.Name = "CheckboxTodos";
            this.CheckboxTodos.Size = new System.Drawing.Size(20, 20);
            this.CheckboxTodos.TabIndex = 0;
            this.CheckboxTodos.OnChange += new System.EventHandler(this.CheckboxTodos_OnChange);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnGenera);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.btnCopiar);
            this.groupBox2.Controls.Add(this.lvFics);
            this.groupBox2.Controls.Add(this.LabelInfo);
            this.groupBox2.Controls.Add(this.btnExaminaDestino);
            this.groupBox2.Controls.Add(this.btnExaminaOrigen);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel9);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel8);
            this.groupBox2.Controls.Add(this.txtDestino);
            this.groupBox2.Controls.Add(this.txtOrigen);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(30, 202);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1017, 348);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Archivos";
            // 
            // btnCopiar
            // 
            this.btnCopiar.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnCopiar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnCopiar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCopiar.BorderRadius = 0;
            this.btnCopiar.ButtonText = "Copiar Archivos";
            this.btnCopiar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCopiar.DisabledColor = System.Drawing.Color.Gray;
            this.btnCopiar.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCopiar.Iconimage = null;
            this.btnCopiar.Iconimage_right = null;
            this.btnCopiar.Iconimage_right_Selected = null;
            this.btnCopiar.Iconimage_Selected = null;
            this.btnCopiar.IconMarginLeft = 0;
            this.btnCopiar.IconMarginRight = 0;
            this.btnCopiar.IconRightVisible = true;
            this.btnCopiar.IconRightZoom = 0D;
            this.btnCopiar.IconVisible = true;
            this.btnCopiar.IconZoom = 90D;
            this.btnCopiar.IsTab = false;
            this.btnCopiar.Location = new System.Drawing.Point(683, 72);
            this.btnCopiar.Name = "btnCopiar";
            this.btnCopiar.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnCopiar.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnCopiar.OnHoverTextColor = System.Drawing.Color.White;
            this.btnCopiar.selected = false;
            this.btnCopiar.Size = new System.Drawing.Size(138, 43);
            this.btnCopiar.TabIndex = 10;
            this.btnCopiar.Text = "Copiar Archivos";
            this.btnCopiar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCopiar.Textcolor = System.Drawing.Color.White;
            this.btnCopiar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopiar.Click += new System.EventHandler(this.btnCopiar_Click);
            // 
            // lvFics
            // 
            this.lvFics.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvFics.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColumnHeader1,
            this.ColumnHeader2});
            this.lvFics.FullRowSelect = true;
            this.lvFics.GridLines = true;
            this.lvFics.HideSelection = false;
            this.lvFics.Location = new System.Drawing.Point(6, 133);
            this.lvFics.Name = "lvFics";
            this.lvFics.Size = new System.Drawing.Size(671, 140);
            this.lvFics.TabIndex = 9;
            this.lvFics.UseCompatibleStateImageBehavior = false;
            this.lvFics.View = System.Windows.Forms.View.Details;
            // 
            // ColumnHeader1
            // 
            this.ColumnHeader1.Text = "Nombre";
            this.ColumnHeader1.Width = 210;
            // 
            // ColumnHeader2
            // 
            this.ColumnHeader2.Text = "Directorio";
            this.ColumnHeader2.Width = 180;
            // 
            // LabelInfo
            // 
            this.LabelInfo.AutoSize = true;
            this.LabelInfo.Location = new System.Drawing.Point(32, 332);
            this.LabelInfo.Name = "LabelInfo";
            this.LabelInfo.Size = new System.Drawing.Size(48, 13);
            this.LabelInfo.TabIndex = 8;
            this.LabelInfo.Text = "Archivos";
            // 
            // btnExaminaDestino
            // 
            this.btnExaminaDestino.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnExaminaDestino.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnExaminaDestino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExaminaDestino.BorderRadius = 0;
            this.btnExaminaDestino.ButtonText = "Examinar";
            this.btnExaminaDestino.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExaminaDestino.DisabledColor = System.Drawing.Color.Gray;
            this.btnExaminaDestino.Iconcolor = System.Drawing.Color.Transparent;
            this.btnExaminaDestino.Iconimage = null;
            this.btnExaminaDestino.Iconimage_right = null;
            this.btnExaminaDestino.Iconimage_right_Selected = null;
            this.btnExaminaDestino.Iconimage_Selected = null;
            this.btnExaminaDestino.IconMarginLeft = 0;
            this.btnExaminaDestino.IconMarginRight = 0;
            this.btnExaminaDestino.IconRightVisible = true;
            this.btnExaminaDestino.IconRightZoom = 0D;
            this.btnExaminaDestino.IconVisible = true;
            this.btnExaminaDestino.IconZoom = 90D;
            this.btnExaminaDestino.IsTab = false;
            this.btnExaminaDestino.Location = new System.Drawing.Point(539, 73);
            this.btnExaminaDestino.Name = "btnExaminaDestino";
            this.btnExaminaDestino.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnExaminaDestino.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnExaminaDestino.OnHoverTextColor = System.Drawing.Color.White;
            this.btnExaminaDestino.selected = false;
            this.btnExaminaDestino.Size = new System.Drawing.Size(138, 43);
            this.btnExaminaDestino.TabIndex = 5;
            this.btnExaminaDestino.Text = "Examinar";
            this.btnExaminaDestino.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnExaminaDestino.Textcolor = System.Drawing.Color.White;
            this.btnExaminaDestino.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExaminaDestino.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // btnExaminaOrigen
            // 
            this.btnExaminaOrigen.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnExaminaOrigen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnExaminaOrigen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExaminaOrigen.BorderRadius = 0;
            this.btnExaminaOrigen.ButtonText = "Examinar";
            this.btnExaminaOrigen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExaminaOrigen.DisabledColor = System.Drawing.Color.Gray;
            this.btnExaminaOrigen.Iconcolor = System.Drawing.Color.Transparent;
            this.btnExaminaOrigen.Iconimage = null;
            this.btnExaminaOrigen.Iconimage_right = null;
            this.btnExaminaOrigen.Iconimage_right_Selected = null;
            this.btnExaminaOrigen.Iconimage_Selected = null;
            this.btnExaminaOrigen.IconMarginLeft = 0;
            this.btnExaminaOrigen.IconMarginRight = 0;
            this.btnExaminaOrigen.IconRightVisible = true;
            this.btnExaminaOrigen.IconRightZoom = 0D;
            this.btnExaminaOrigen.IconVisible = true;
            this.btnExaminaOrigen.IconZoom = 90D;
            this.btnExaminaOrigen.IsTab = false;
            this.btnExaminaOrigen.Location = new System.Drawing.Point(539, 19);
            this.btnExaminaOrigen.Name = "btnExaminaOrigen";
            this.btnExaminaOrigen.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnExaminaOrigen.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnExaminaOrigen.OnHoverTextColor = System.Drawing.Color.White;
            this.btnExaminaOrigen.selected = false;
            this.btnExaminaOrigen.Size = new System.Drawing.Size(138, 43);
            this.btnExaminaOrigen.TabIndex = 4;
            this.btnExaminaOrigen.Text = "Examinar";
            this.btnExaminaOrigen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnExaminaOrigen.Textcolor = System.Drawing.Color.White;
            this.btnExaminaOrigen.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExaminaOrigen.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(32, 103);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(91, 13);
            this.bunifuCustomLabel9.TabIndex = 3;
            this.bunifuCustomLabel9.Text = "Directorio Destino";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(32, 51);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(86, 13);
            this.bunifuCustomLabel8.TabIndex = 2;
            this.bunifuCustomLabel8.Text = "Directorio Origen";
            // 
            // txtDestino
            // 
            this.txtDestino.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDestino.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtDestino.ForeColor = System.Drawing.Color.White;
            this.txtDestino.HintForeColor = System.Drawing.Color.Empty;
            this.txtDestino.HintText = "";
            this.txtDestino.isPassword = false;
            this.txtDestino.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtDestino.LineIdleColor = System.Drawing.Color.Gray;
            this.txtDestino.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtDestino.LineThickness = 3;
            this.txtDestino.Location = new System.Drawing.Point(212, 72);
            this.txtDestino.Margin = new System.Windows.Forms.Padding(4);
            this.txtDestino.Name = "txtDestino";
            this.txtDestino.Size = new System.Drawing.Size(320, 44);
            this.txtDestino.TabIndex = 1;
            this.txtDestino.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtOrigen
            // 
            this.txtOrigen.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtOrigen.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtOrigen.ForeColor = System.Drawing.Color.White;
            this.txtOrigen.HintForeColor = System.Drawing.Color.Empty;
            this.txtOrigen.HintText = "";
            this.txtOrigen.isPassword = false;
            this.txtOrigen.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtOrigen.LineIdleColor = System.Drawing.Color.Gray;
            this.txtOrigen.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtOrigen.LineThickness = 3;
            this.txtOrigen.Location = new System.Drawing.Point(212, 20);
            this.txtOrigen.Margin = new System.Windows.Forms.Padding(4);
            this.txtOrigen.Name = "txtOrigen";
            this.txtOrigen.Size = new System.Drawing.Size(320, 44);
            this.txtOrigen.TabIndex = 0;
            this.txtOrigen.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // rbtRetenciones
            // 
            this.rbtRetenciones.AutoSize = true;
            this.rbtRetenciones.Location = new System.Drawing.Point(209, 65);
            this.rbtRetenciones.Name = "rbtRetenciones";
            this.rbtRetenciones.Size = new System.Drawing.Size(85, 17);
            this.rbtRetenciones.TabIndex = 11;
            this.rbtRetenciones.TabStop = true;
            this.rbtRetenciones.Text = "Retenciones";
            this.rbtRetenciones.UseVisualStyleBackColor = true;
            // 
            // rbtDisolucion
            // 
            this.rbtDisolucion.AutoSize = true;
            this.rbtDisolucion.Location = new System.Drawing.Point(33, 65);
            this.rbtDisolucion.Name = "rbtDisolucion";
            this.rbtDisolucion.Size = new System.Drawing.Size(74, 17);
            this.rbtDisolucion.TabIndex = 12;
            this.rbtDisolucion.TabStop = true;
            this.rbtDisolucion.Text = "Disolucion";
            this.rbtDisolucion.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbtDisolucion);
            this.groupBox3.Controls.Add(this.rbtRetenciones);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox3.Location = new System.Drawing.Point(683, 133);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox3.Size = new System.Drawing.Size(328, 143);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Seleccionar Dashboar a Generar";
            // 
            // btnGenera
            // 
            this.btnGenera.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnGenera.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnGenera.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnGenera.BorderRadius = 0;
            this.btnGenera.ButtonText = "Generar Dashboard";
            this.btnGenera.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGenera.DisabledColor = System.Drawing.Color.Gray;
            this.btnGenera.Iconcolor = System.Drawing.Color.Transparent;
            this.btnGenera.Iconimage = null;
            this.btnGenera.Iconimage_right = null;
            this.btnGenera.Iconimage_right_Selected = null;
            this.btnGenera.Iconimage_Selected = null;
            this.btnGenera.IconMarginLeft = 0;
            this.btnGenera.IconMarginRight = 0;
            this.btnGenera.IconRightVisible = true;
            this.btnGenera.IconRightZoom = 0D;
            this.btnGenera.IconVisible = true;
            this.btnGenera.IconZoom = 90D;
            this.btnGenera.IsTab = false;
            this.btnGenera.Location = new System.Drawing.Point(873, 282);
            this.btnGenera.Name = "btnGenera";
            this.btnGenera.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnGenera.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnGenera.OnHoverTextColor = System.Drawing.Color.White;
            this.btnGenera.selected = false;
            this.btnGenera.Size = new System.Drawing.Size(138, 43);
            this.btnGenera.TabIndex = 16;
            this.btnGenera.Text = "Generar Dashboard";
            this.btnGenera.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGenera.Textcolor = System.Drawing.Color.White;
            this.btnGenera.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenera.Click += new System.EventHandler(this.btnGenera_Click);
            // 
            // GeneraDashboards
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1077, 596);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GeneraDashboards";
            this.Text = "GeneraDashboards";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuCheckbox CheckboxTodos;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTodos;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCheckbox CheckboxD;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCheckbox CheckboxS;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCheckbox CheckboxV;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCheckbox CheckboxJ;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCheckbox CheckboxMi;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCheckbox CheckboxMa;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCheckbox CheckboxL;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtDestino;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtOrigen;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuFlatButton btnExaminaOrigen;
        private Bunifu.Framework.UI.BunifuFlatButton btnExaminaDestino;
        private Bunifu.Framework.UI.BunifuCustomLabel LabelInfo;
        private System.Windows.Forms.ListView lvFics;
        private System.Windows.Forms.ColumnHeader ColumnHeader1;
        private System.Windows.Forms.ColumnHeader ColumnHeader2;
        private Bunifu.Framework.UI.BunifuFlatButton btnCopiar;
        private System.Windows.Forms.RadioButton rbtRetenciones;
        private System.Windows.Forms.RadioButton rbtDisolucion;
        private System.Windows.Forms.GroupBox groupBox3;
        private Bunifu.Framework.UI.BunifuFlatButton btnGenera;
    }
}