﻿namespace Dashboard
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelContenedor = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblNoBatch = new System.Windows.Forms.Label();
            this.lblDetalleFecha4 = new System.Windows.Forms.Label();
            this.lblBatch = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblNoDbsbif = new System.Windows.Forms.Label();
            this.lblDetalleFecha3 = new System.Windows.Forms.Label();
            this.lblDbsbif = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.lblNoInactivas = new System.Windows.Forms.Label();
            this.lblDetalleFecha2 = new System.Windows.Forms.Label();
            this.lblInactivas = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.lblNoActivas = new System.Windows.Forms.Label();
            this.lblDetalleFecha1 = new System.Windows.Forms.Label();
            this.lblActivas = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelContenedor.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelContenedor
            // 
            this.panelContenedor.AutoScroll = true;
            this.panelContenedor.AutoSize = true;
            this.panelContenedor.Controls.Add(this.panel11);
            this.panelContenedor.Controls.Add(this.panel12);
            this.panelContenedor.Controls.Add(this.panel8);
            this.panelContenedor.Controls.Add(this.panel10);
            this.panelContenedor.Controls.Add(this.panel5);
            this.panelContenedor.Controls.Add(this.panel7);
            this.panelContenedor.Controls.Add(this.panel13);
            this.panelContenedor.Controls.Add(this.panel14);
            this.panelContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContenedor.Location = new System.Drawing.Point(0, 0);
            this.panelContenedor.Name = "panelContenedor";
            this.panelContenedor.Size = new System.Drawing.Size(1093, 635);
            this.panelContenedor.TabIndex = 18;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel11.Controls.Add(this.pictureBox8);
            this.panel11.Controls.Add(this.label15);
            this.panel11.Location = new System.Drawing.Point(551, 391);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(531, 231);
            this.panel11.TabIndex = 30;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(18, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 25);
            this.label15.TabIndex = 0;
            this.label15.Text = "Via 4";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel12.Controls.Add(this.pictureBox9);
            this.panel12.Controls.Add(this.label22);
            this.panel12.Location = new System.Drawing.Point(11, 391);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(525, 231);
            this.panel12.TabIndex = 29;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(18, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 25);
            this.label22.TabIndex = 0;
            this.label22.Text = "Via 3";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel8.Controls.Add(this.pictureBox7);
            this.panel8.Controls.Add(this.label13);
            this.panel8.Location = new System.Drawing.Point(551, 154);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(531, 231);
            this.panel8.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(18, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 25);
            this.label13.TabIndex = 0;
            this.label13.Text = "Via 2";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel10.Controls.Add(this.pictureBox6);
            this.panel10.Controls.Add(this.lblNoBatch);
            this.panel10.Controls.Add(this.lblDetalleFecha4);
            this.panel10.Controls.Add(this.lblBatch);
            this.panel10.Location = new System.Drawing.Point(824, 8);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(258, 130);
            this.panel10.TabIndex = 26;
            // 
            // lblNoBatch
            // 
            this.lblNoBatch.AutoSize = true;
            this.lblNoBatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoBatch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.lblNoBatch.Location = new System.Drawing.Point(17, 57);
            this.lblNoBatch.Name = "lblNoBatch";
            this.lblNoBatch.Size = new System.Drawing.Size(100, 32);
            this.lblNoBatch.TabIndex = 1;
            this.lblNoBatch.Text = "$1234";
            // 
            // lblDetalleFecha4
            // 
            this.lblDetalleFecha4.AutoSize = true;
            this.lblDetalleFecha4.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetalleFecha4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(161)))), ((int)(((byte)(176)))));
            this.lblDetalleFecha4.Location = new System.Drawing.Point(3, 97);
            this.lblDetalleFecha4.Name = "lblDetalleFecha4";
            this.lblDetalleFecha4.Size = new System.Drawing.Size(137, 17);
            this.lblDetalleFecha4.TabIndex = 0;
            this.lblDetalleFecha4.Text = "Details of last 28 Days";
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatch.ForeColor = System.Drawing.Color.White;
            this.lblBatch.Location = new System.Drawing.Point(18, 22);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(68, 25);
            this.lblBatch.TabIndex = 0;
            this.lblBatch.Text = "BATCH";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Controls.Add(this.lblNoDbsbif);
            this.panel5.Controls.Add(this.lblDetalleFecha3);
            this.panel5.Controls.Add(this.lblDbsbif);
            this.panel5.Location = new System.Drawing.Point(551, 8);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(258, 130);
            this.panel5.TabIndex = 27;
            // 
            // lblNoDbsbif
            // 
            this.lblNoDbsbif.AutoSize = true;
            this.lblNoDbsbif.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoDbsbif.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.lblNoDbsbif.Location = new System.Drawing.Point(17, 57);
            this.lblNoDbsbif.Name = "lblNoDbsbif";
            this.lblNoDbsbif.Size = new System.Drawing.Size(100, 32);
            this.lblNoDbsbif.TabIndex = 1;
            this.lblNoDbsbif.Text = "$1234";
            // 
            // lblDetalleFecha3
            // 
            this.lblDetalleFecha3.AutoSize = true;
            this.lblDetalleFecha3.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetalleFecha3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(161)))), ((int)(((byte)(176)))));
            this.lblDetalleFecha3.Location = new System.Drawing.Point(5, 97);
            this.lblDetalleFecha3.Name = "lblDetalleFecha3";
            this.lblDetalleFecha3.Size = new System.Drawing.Size(137, 17);
            this.lblDetalleFecha3.TabIndex = 0;
            this.lblDetalleFecha3.Text = "Details of last 28 Days";
            // 
            // lblDbsbif
            // 
            this.lblDbsbif.AutoSize = true;
            this.lblDbsbif.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDbsbif.ForeColor = System.Drawing.Color.White;
            this.lblDbsbif.Location = new System.Drawing.Point(18, 22);
            this.lblDbsbif.Name = "lblDbsbif";
            this.lblDbsbif.Size = new System.Drawing.Size(71, 25);
            this.lblDbsbif.TabIndex = 0;
            this.lblDbsbif.Text = "DBSBIF";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel7.Controls.Add(this.pictureBox4);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Location = new System.Drawing.Point(11, 154);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(525, 231);
            this.panel7.TabIndex = 23;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(18, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 25);
            this.label14.TabIndex = 0;
            this.label14.Text = "Via 1";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel13.Controls.Add(this.pictureBox3);
            this.panel13.Controls.Add(this.lblNoInactivas);
            this.panel13.Controls.Add(this.lblDetalleFecha2);
            this.panel13.Controls.Add(this.lblInactivas);
            this.panel13.Location = new System.Drawing.Point(278, 8);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(258, 130);
            this.panel13.TabIndex = 24;
            // 
            // lblNoInactivas
            // 
            this.lblNoInactivas.AutoSize = true;
            this.lblNoInactivas.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoInactivas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(226)))), ((int)(((byte)(178)))));
            this.lblNoInactivas.Location = new System.Drawing.Point(17, 57);
            this.lblNoInactivas.Name = "lblNoInactivas";
            this.lblNoInactivas.Size = new System.Drawing.Size(86, 32);
            this.lblNoInactivas.TabIndex = 1;
            this.lblNoInactivas.Text = "12K+";
            // 
            // lblDetalleFecha2
            // 
            this.lblDetalleFecha2.AutoSize = true;
            this.lblDetalleFecha2.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetalleFecha2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(161)))), ((int)(((byte)(176)))));
            this.lblDetalleFecha2.Location = new System.Drawing.Point(3, 97);
            this.lblDetalleFecha2.Name = "lblDetalleFecha2";
            this.lblDetalleFecha2.Size = new System.Drawing.Size(137, 17);
            this.lblDetalleFecha2.TabIndex = 0;
            this.lblDetalleFecha2.Text = "Details of last 28 Days";
            // 
            // lblInactivas
            // 
            this.lblInactivas.AutoSize = true;
            this.lblInactivas.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInactivas.ForeColor = System.Drawing.Color.White;
            this.lblInactivas.Location = new System.Drawing.Point(18, 22);
            this.lblInactivas.Name = "lblInactivas";
            this.lblInactivas.Size = new System.Drawing.Size(85, 25);
            this.lblInactivas.TabIndex = 0;
            this.lblInactivas.Text = "Inactivas";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel14.Controls.Add(this.pictureBox2);
            this.panel14.Controls.Add(this.lblNoActivas);
            this.panel14.Controls.Add(this.lblDetalleFecha1);
            this.panel14.Controls.Add(this.lblActivas);
            this.panel14.Location = new System.Drawing.Point(11, 8);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(258, 130);
            this.panel14.TabIndex = 25;
            // 
            // lblNoActivas
            // 
            this.lblNoActivas.AutoSize = true;
            this.lblNoActivas.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoActivas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.lblNoActivas.Location = new System.Drawing.Point(17, 57);
            this.lblNoActivas.Name = "lblNoActivas";
            this.lblNoActivas.Size = new System.Drawing.Size(100, 32);
            this.lblNoActivas.TabIndex = 1;
            this.lblNoActivas.Text = "$1234";
            // 
            // lblDetalleFecha1
            // 
            this.lblDetalleFecha1.AutoSize = true;
            this.lblDetalleFecha1.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetalleFecha1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(161)))), ((int)(((byte)(176)))));
            this.lblDetalleFecha1.Location = new System.Drawing.Point(5, 97);
            this.lblDetalleFecha1.Name = "lblDetalleFecha1";
            this.lblDetalleFecha1.Size = new System.Drawing.Size(137, 17);
            this.lblDetalleFecha1.TabIndex = 0;
            this.lblDetalleFecha1.Text = "Details of last 28 Days";
            // 
            // lblActivas
            // 
            this.lblActivas.AutoSize = true;
            this.lblActivas.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActivas.ForeColor = System.Drawing.Color.White;
            this.lblActivas.Location = new System.Drawing.Point(18, 22);
            this.lblActivas.Name = "lblActivas";
            this.lblActivas.Size = new System.Drawing.Size(71, 25);
            this.lblActivas.TabIndex = 0;
            this.lblActivas.Text = "Activas";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Dashboard.Properties.Resources.chart_diagram1;
            this.pictureBox8.Location = new System.Drawing.Point(23, 69);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(492, 135);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 2;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Dashboard.Properties.Resources.chart_diagram1;
            this.pictureBox9.Location = new System.Drawing.Point(23, 69);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(486, 135);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 2;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Dashboard.Properties.Resources.chart_diagram1;
            this.pictureBox7.Location = new System.Drawing.Point(23, 69);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(492, 135);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Dashboard.Properties.Resources.batch;
            this.pictureBox6.Location = new System.Drawing.Point(146, 5);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 92);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Dashboard.Properties.Resources.dbsbif;
            this.pictureBox5.Location = new System.Drawing.Point(148, 5);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 92);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Dashboard.Properties.Resources.chart_diagram1;
            this.pictureBox4.Location = new System.Drawing.Point(23, 69);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(486, 135);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Dashboard.Properties.Resources.inactive;
            this.pictureBox3.Location = new System.Drawing.Point(146, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 92);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Dashboard.Properties.Resources.active;
            this.pictureBox2.Location = new System.Drawing.Point(148, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 92);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1093, 635);
            this.Controls.Add(this.panelContenedor);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.panelContenedor.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelContenedor;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label lblNoBatch;
        private System.Windows.Forms.Label lblDetalleFecha4;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lblNoDbsbif;
        private System.Windows.Forms.Label lblDetalleFecha3;
        private System.Windows.Forms.Label lblDbsbif;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lblNoInactivas;
        private System.Windows.Forms.Label lblDetalleFecha2;
        private System.Windows.Forms.Label lblInactivas;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblNoActivas;
        private System.Windows.Forms.Label lblDetalleFecha1;
        private System.Windows.Forms.Label lblActivas;
    }
}