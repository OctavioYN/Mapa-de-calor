﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Globalization;

namespace Dashboard
{
    public partial class GeneraDashboards : Form
    {
        public GeneraDashboards()
        {
            InitializeComponent();
        }

        // Para simular la variable Static de VB
        private bool yaEstoy__1;


        private void CheckboxTodos_OnChange(object sender, EventArgs e)
        {
            if (CheckboxTodos.Checked == true)
            {
                CheckboxL.Checked = true;
                CheckboxMa.Checked = true;
                CheckboxMi.Checked = true;
                CheckboxJ.Checked = true;
                CheckboxV.Checked = true;
                CheckboxS.Checked = true;
                CheckboxD.Checked = true;

            }
            else
            {
                CheckboxL.Checked = false;
                CheckboxMa.Checked = false;
                CheckboxMi.Checked = false;
                CheckboxJ.Checked = false;
                CheckboxV.Checked = false;
                CheckboxS.Checked = false;
                CheckboxD.Checked = false;

            }



        }


        public Boolean copiarArchivos(String ruta,String nombre ,string dstDirPath, Boolean f) {
            Boolean estatus=true;

            DateTime fecha = DateTime.Now;

            string mes = fecha.ToString("MM");
            string dia = fecha.ToString("dd");
            string a = fecha.ToString("yy");

            string srcFilePath="";
            string dstFilePath="";

            if (f)
            {
                srcFilePath = @ruta + nombre + a + mes + dia + ".txt";
                dstFilePath=Path.Combine(dstDirPath, Path.GetFileName(srcFilePath));
            }
            else
            {
                srcFilePath = @ruta + nombre +".txt";
                dstFilePath = Path.Combine(dstDirPath, Path.GetFileName(srcFilePath));
            }
            // Ruta del archivo a copiar.
            

            // Destino archivo.
            //string dstDirPath = @"C:\Users\xmy8196_1\Documents\CS";

            // Destino final del archivo.
            

            try
            {
                Directory.CreateDirectory(dstDirPath);
                File.Copy(srcFilePath, dstFilePath, overwrite: false);
                Console.WriteLine("Archivo copiado con exito");
                estatus = true;
                //MessageBox.Show("Archivo copiado con exito");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Archivo no copiado", ex);
                //MessageBox.Show("Archivo no copiado "+ex);
                //throw;
                estatus = false;
            }

            return estatus;
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog oFD = new FolderBrowserDialog();
            oFD.Description = "Seleccionar el directorio de búsqueda";
            oFD.RootFolder = Environment.SpecialFolder.MyComputer;
            oFD.SelectedPath = this.txtOrigen.Text;
            if (oFD.ShowDialog() == DialogResult.OK)
            {
                this.txtOrigen.Text = oFD.SelectedPath;
            }

            buscar();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog oFD = new FolderBrowserDialog();
            oFD.Description = "Seleccionar el directorio de búsqueda";
            oFD.RootFolder = Environment.SpecialFolder.MyComputer;
            oFD.SelectedPath = this.txtDestino.Text;
            if (oFD.ShowDialog() == DialogResult.OK)
            {
                this.txtDestino.Text = oFD.SelectedPath;
            }

        }


        public void buscar() {

            // Buscar de forma recursiva (si es necesario)
            //*** era Static *** yaEstoy__1;

            if (yaEstoy__1)
            {

                this.btnExaminaOrigen.Text = "Cancelando...";
                Application.DoEvents();
                return;
            }
            yaEstoy__1 = true;


            DirectoryInfo di = new DirectoryInfo(txtOrigen.Text);

            this.lvFics.Items.Clear();
            this.LabelInfo.Text = "Buscando los ficheros...";
            this.Cursor = Cursors.AppStarting;
            this.btnExaminaOrigen.Text = "Buscando...";
            this.Refresh();

            recorrerDir(di);

            this.Cursor = Cursors.Default;
            this.LabelInfo.Text = "Se han hallado " + this.lvFics.Items.Count + " ficheros";
            this.btnExaminaOrigen.Text = "Examinar";

            if (this.lvFics.Items.Count > 0)
            {
                //this.btnAbrirDir.Enabled = true;
                //this.btnAbrirFic.Enabled = true;
            }
            this.Refresh();

            
            yaEstoy__1 = false;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {

           
        }


        private void recorrerDir(DirectoryInfo di)
        {
            // Recorrer los ficheros de este directorio
            // añadir al listview si se encuentra alguno
            FileInfo[] fics;
            DirectoryInfo[] dirs;



            this.LabelInfo.Text = di.FullName + "...";
            this.LabelInfo.Refresh();

            try
            {
                fics = di.GetFiles("*.*", SearchOption.TopDirectoryOnly);
                foreach (FileInfo fi in fics)
                {
                    ListViewItem lvi = this.lvFics.Items.Add(fi.Name);
                    lvi.SubItems.Add(fi.DirectoryName);
                }
                //this.lvFics.Refresh();
                if (true)
                {
                    dirs = di.GetDirectories();
                    foreach (DirectoryInfo dir in dirs)
                    {
                        recorrerDir(dir);
                    }
                }
            }
            catch (Exception ex)
            {
                if (true)
                {
                    return;
                }
                if (MessageBox.Show("Error: " + ex.Message + "\n" +
                                   "¿Quieres cancelar o continuar?",
                                   "Buscar en directorios",
                                   MessageBoxButtons.OKCancel,
                                   MessageBoxIcon.Exclamation
                                   ) == DialogResult.Cancel)
                {
                    //cancelar = true;
                    Application.DoEvents();
                }
            }
        }






        private void btnCopiar_Click(object sender, EventArgs e)
        {
            Boolean archivo1, archivo2, archivo3, archivo4, archivo5, archivo6, archivo7, archivo8, archivo9, archivo10;
            DateTime fecha = DateTime.Now;
            
            DateTime dia = Convert.ToDateTime(fecha);
            
            string dia1 = dia.ToString("dddd", new CultureInfo("es-ES"));

            MessageBox.Show("Dia:" + dia1);

            //String ruta, String nombre ,string dstDirPath, Boolean f)

            //DISOLUCION DE LUNES A DOMINGO 7:30AM



            if (CheckboxTodos.Checked == true)
            {
                archivo1 = copiarArchivos(txtOrigen.Text, "DADMCON.F", txtDestino.Text, true);
                archivo2 = copiarArchivos(txtOrigen.Text, "DADMTDC.F", txtDestino.Text, true);
                archivo3 = copiarArchivos(txtOrigen.Text, "VIDMCON.F", txtDestino.Text, true);
                archivo4 = copiarArchivos(txtOrigen.Text, "VIDMTDC.F", txtDestino.Text, true);
            }

            //Aplicados 5:30 PM APROX DE LUNES A VIERNES

            if (CheckboxL.Checked == true & dia1 == "lunes" | dia1 == "martes" | dia1 == "miercoles" | dia1 == "jueves" | dia1 == "viernes")
            {
                archivo5 = copiarArchivos(txtOrigen.Text, "RI3CRA18_CO", txtDestino.Text, false);
                archivo6 = copiarArchivos(txtOrigen.Text, "RI3CRA26_MP", txtDestino.Text, false);
            }

            //CS LOS LUNES
            if (CheckboxL.Checked==true & dia1 =="lunes")
            {
                //MessageBox.Show("Entrando a la condicion");
                archivo7 = copiarArchivos(txtOrigen.Text, "REP_CONSUMO", txtDestino.Text, false);
                archivo8 = copiarArchivos(txtOrigen.Text, "REP_TARJETA", txtDestino.Text, false);
            }

            //Retenciones MARTES A SABADO 
            if (CheckboxL.Checked == true & dia1 == "martes" | dia1=="miercoles" | dia1 == "jueves" | dia1 == "viernes" | dia1 == "sabado")
            {
                archivo9 = copiarArchivos(txtOrigen.Text, "RI3CRA15", txtDestino.Text, false);
                archivo10 = copiarArchivos(txtOrigen.Text, "RI3CRA15_MP", txtDestino.Text, false);
            }



        }

        private void btnGenera_Click(object sender, EventArgs e)
        {
            if(rbtDisolucion.Checked)
            {

                MessageBox.Show("Disolucion Generada");

            }
            if(rbtRetenciones.Checked)
            {

                MessageBox.Show("Retencion Generada");

            }
        }
    }



    // Simular (en parte) el objeto My de Visual Basic 2005
    // My.Settings y My.Application.Info
    static class My
    {
        public static Properties.Settings Settings
        {
            get
            {
                return Properties.Settings.Default;
            }
        }

        // My.Application.Info
        public static class Application
        {
            public static class Info
            {
                static System.Diagnostics.FileVersionInfo fvi;
                static System.Reflection.Assembly ensamblado;

                static Info()
                {
                    ensamblado = System.Reflection.Assembly.GetExecutingAssembly();
                    fvi = FileVersionInfo.GetVersionInfo(ensamblado.Location);
                }
                public static Version Version
                {
                    get
                    {
                        return new Version(fvi.FileVersion);
                    }
                }
                public static string Title
                {
                    get
                    {
                        return fvi.ProductName;
                    }
                }
                public static string Copyright
                {
                    get
                    {
                        return fvi.LegalCopyright;
                    }
                }
            }
        }
    }
}