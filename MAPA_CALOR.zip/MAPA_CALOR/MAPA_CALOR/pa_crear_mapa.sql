DELIMITER //
CREATE PROCEDURE pa_crear_mapa(IN mes int)
BEGIN

	 SET @@global.sql_mode= '';
	 SET SESSION group_concat_max_len = 100000;
	 
     SET SQL_SAFE_UPDATES = 0;
	 
	INSERT INTO tblinfoHistorica SELECT*FROM tblinfoaldia ;

	Drop table if exists tblinfoend_time;
	Create table tblinfoend_time as select a.* ,b.odate, time(b.et) as et  
	from tbljobsmetacliente a
	left JOIN tblinfoHistorica as b ON a.jobs = b.JOBNAME
	and month(b.odate)=mes
	ORDER BY a.id;

	UPDATE tblinfoend_time SET Meta_Cliente_ac= Meta_cliente;
	UPDATE tblinfoend_time SET Meta_Cliente_ac= ADDDATE(Meta_cliente, INTERVAL 2 hour) WHERE day(odate) in (1,2,3,4,5,15,16,17,18,30,31);


	Drop table if exists tblpivot0;
	Create table tblpivot0
	SELECT *,
	CASE
		WHEN et <= "12:00:00" THEN "Dia"
		WHEN et <="18:00:00" THEN "Tarde"
		ELSE "Noche"
	end as Horario
	from tblinfoend_time;
	 
	 Drop table if exists tblpivot00;
	 Create table tblpivot00
	 select *,
	 Case
	   WHEN Horario = "Dia" THEN TIME_TO_SEC(TIMEDIFF(et,Meta_Cliente_ac))/60 
		WHEN Horario ="Noche" THEN TIME_TO_SEC(TIMEDIFF(Meta_Cliente_ac,et))/60
		ELSE TIME_TO_SEC(TIMEDIFF(et,Meta_Cliente_ac))/60
	 end as Diferencia
	from tblpivot0;
    
    
    
	 
	Drop table if exists tblpivot000;
	Create table tblpivot000
	select *,
	 Case
	   WHEN Diferencia <= 15 THEN 100
	   WHEN Diferencia >15 and Diferencia <=30 THEN 95
	   WHEN Diferencia >30 and Diferencia <=60 THEN 90
	   WHEN Diferencia >60 and Diferencia <=90 THEN 85
	   WHEN Diferencia >90 and Diferencia <=120 THEN 80
	   WHEN Diferencia >120 and Diferencia <=150 THEN 75
	   WHEN Diferencia >150 and Diferencia <=180 THEN 70
	   WHEN Diferencia >180 and Diferencia <=210 THEN 60
	   WHEN Diferencia >210 and Diferencia <=1440 THEN 50   
	   ELSE 0
	 end as Pr 
	 from tblpivot00;
	 
	 
	 select* from tblpivot000;
	 
	/*Eliminar tabla pivot1 y Transponer Dias cradno tabla pivor1 HORARIO NORMAL*/

	Drop table if exists tblpivot1;

	SET @sql = NULL;
	SELECT
	GROUP_CONCAT(DISTINCT
	CONCAT(
	"max(case when odate = """,
	odate,
	""" then et end) ",
	"'",DAY(odate),"'"
	)
	) INTO @sql
	FROM
	tblinfoend_time;
	SET @sql = CONCAT("Create table tblpivot1 SELECT jobs, ", @sql, "
	FROM tblinfoend_time
	GROUP BY jobs");

	SELECT @SQL;
	PREPARE stmt FROM @sql;
	EXECUTE stmt;
	-- DEALLOCATE PREPARE stmt;


	select*from tblpivot1;
	select*from tblinfoend_time;

	Drop table if exists tblpivot2;

	SET @sql = NULL;
	SELECT
	GROUP_CONCAT(DISTINCT
	CONCAT
	(
	"max(case when odate = """,odate,""" then pr end) ","'",DAY(odate),"'"
	)
	) INTO @sql
	FROM
	tblpivot000;
	SET @sql = CONCAT("Create table tblpivot2 SELECT jobs, ", @sql,",IFNULL(CAST(AVG(pr) AS DECIMAL(10,2)), NULL) AS Prom 
	FROM tblpivot000
	GROUP BY jobs");

	SELECT @SQL;
	PREPARE stmt FROM @sql;
	EXECUTE stmt;
	-- DEALLOCATE PREPARE stmt;


	select*from tblpivot2;
	select*from tblpivot1;


	Drop table if exists tblMapaCalor;
	Create table tblMapaCalor as
	SELECT  b.Descripcion,b.Meta,b.Cartera,b.Estadío,b.Nombre_Archivo,b.Meta_Cliente,
	a.*,c.prom as Promedio
	FROM tblpivot1 as a
	left JOIN tbljobsmetacliente as b ON a.jobs =b.jobs
	left JOIN tblpivot2 as c ON a.jobs =c.jobs
	ORDER BY b.id;

	select*from tblMapaCalor;

	-- resetear la tabla con informacion del dia para no duplicar informacion
	TRUNCATE TABLE tblinfoaldia;

end//

DELIMITER ;




select*from tblinfoaldia;
LOAD DATA INFILE 'D:/Mapa_Calor/Excel xls/FALTANTES3.txt'
INTO TABLE tblinfoaldia 
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n';


CALL pa_crear_mapa(08);
