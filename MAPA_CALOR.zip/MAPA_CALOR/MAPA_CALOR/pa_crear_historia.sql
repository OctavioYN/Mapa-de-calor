DELIMITER //
CREATE PROCEDURE pa_crear_Historia()
BEGIN

INSERT INTO tblinfoHistorica SELECT*FROM tblinfoaldia;

END//

DELIMITER ;


-- CALL pa_listainmuebles();
