/*	1.- Descargar scheduling del dia
	2. Abrir excel convertir las columnas en Formato de Celda/Personalizada dd/mm/aaaa hh:mm:ss
	3. Guardar excel como 	Libro de excel 97-2003
    4. Abrir app Mapa de calor/ Seleccionar el archivo del dia/Guardar
*/

/*
CREATE TABLE `tblinfoaldia` (
  `No` int DEFAULT NULL,
  `JOBNAME` varchar(10) DEFAULT NULL,
  `FOLDER` varchar(15) DEFAULT NULL,
  `APPLICATION` varchar(15) DEFAULT NULL,
  `SUB_APPLICATION` varchar(17) DEFAULT NULL,
  `RUN_AS` varchar(9) DEFAULT NULL,
  `ORDERID` varchar(5) DEFAULT NULL,
  `ODATE` date DEFAULT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `HOST` varchar(14) DEFAULT NULL,
  `STATUS` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;*/


/*
CREATE TABLE `tblinfoHistorica` (
  `No` int DEFAULT NULL,
  `JOBNAME` varchar(10) DEFAULT NULL,
  `FOLDER` varchar(15) DEFAULT NULL,
  `APPLICATION` varchar(15) DEFAULT NULL,
  `SUB_APPLICATION` varchar(17) DEFAULT NULL,
  `RUN_AS` varchar(9) DEFAULT NULL,
  `ORDERID` varchar(5) DEFAULT NULL,
  `ODATE` date DEFAULT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `HOST` varchar(14) DEFAULT NULL,
  `STATUS` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
*/


 
select * from  tblinfoaldia where JOBNAME='MCOBTP0C33';

TRUNCATE TABLE tblinfoaldia;
TRUNCATE TABLE tblinfoHistorica;


select *from  tblinfoHistorica;
-- TRUNCATE TABLE tblinfoHistorica;

select*from tblinfoEnd_Time;

UPDATE tbljobsmetacliente SET Meta_Cliente_ac= ADDDATE(Meta_cliente, INTERVAL 3 hour) WHERE day in (1,2,3,4,5,15,16,17,18,30,31);

INSERT INTO tblinfoHistorica SELECT*FROM tblinfoaldia;

select  day(odate) from tblinfoHistorica 


Drop table if exists tblinfoEnd_Time;
Create table tblinfoEnd_Time as
select a.* ,b.odate, time(b.END_TIME) as END_TIME 
from tbljobsmetacliente a, tblinfoHistorica b 
where a.Jobs=b.JOBNAME 
and b.odate=current_date()
ORDER BY a.id;

ALTER TABLE `db_mapa_calor`.`tblinfoend_time` 
ADD COLUMN `Meta_Cliente_Ac` TIME NULL DEFAULT NULL AFTER `END_TIME`;

UPDATE tblinfoend_time SET Meta_Cliente_ac= Meta_cliente;
UPDATE tblinfoend_time SET Meta_Cliente_ac= ADDDATE(Meta_cliente, INTERVAL 2 hour) WHERE day(odate) in (1,2,3,4,5,15,16,17,18,30,31);


select*from tblinfoEnd_Time;

SELECT DATE_ADD(CURDATE(), INTERVAL 1 month);-- mas 1 mes
SELECT SUBDATE(CURDATE(), INTERVAL 1 month);-- menos 1 mes

Drop table if exists tblpivot0;
Create table tblpivot0
SELECT *,
CASE
    WHEN end_time <= "12:00:00" THEN "Dia"
    WHEN end_time <="18:00:00" THEN "Tarde"
    ELSE "Noche"
END as Horario
from tblinfoEnd_Time;
 

 select Meta_cliente,ADDDATE(Meta_cliente, INTERVAL 3 hour) as SumaHoras  from tblinfoEnd_Time
 
 Drop table if exists tblpivot00;
 Create table tblpivot00
 select *,
 Case
   WHEN Horario = "Dia" THEN TIME_TO_SEC(TIMEDIFF(end_time,Meta_cliente))/60 
    WHEN Horario ="Noche" THEN TIME_TO_SEC(TIMEDIFF(Meta_cliente,end_time))/60
    ELSE TIME_TO_SEC(TIMEDIFF(end_time,Meta_cliente))/60
 End as Diferencia
from tblpivot0;
 
Drop table if exists tblpivot000;
Create table tblpivot000
select *,
 Case
   WHEN Diferencia <= 15 THEN 100
   WHEN Diferencia >=16 and diferencia <=30 THEN 95
   WHEN Diferencia >=31 and diferencia <=60 THEN 90
   WHEN Diferencia >=61 and diferencia <=90 THEN 85
   WHEN Diferencia >=91 and diferencia <=120 THEN 80
   WHEN Diferencia >=121 and diferencia <=150 THEN 75
   WHEN Diferencia >=151 and diferencia <=180 THEN 70
   WHEN Diferencia >=181 and diferencia <=210 THEN 60
   WHEN Diferencia >=211 and diferencia <=1440 THEN 50   
   ELSE 0
 End as Pr 
 from tblpivot00;
 
 
 select* from tblpivot000;
 
/*Eliminar tabla pivot1 y Transponer Dias cradno tabla pivor1 HORARIO NORMAL*/

Drop table if exists tblpivot1;

SET @sql = NULL;
SELECT
GROUP_CONCAT(DISTINCT
CONCAT(
"max(case when odate = """,
odate,
""" then end_time end) ",
"'",DAY(odate),"'"
)
) INTO @sql
FROM
tblinfoEnd_Time;
SET @sql = CONCAT("Create table tblpivot1 SELECT jobs, ", @sql, "
FROM tblinfoEnd_Time
GROUP BY jobs");

SELECT @SQL;
PREPARE stmt FROM @sql;
EXECUTE stmt;
-- DEALLOCATE PREPARE stmt;


select*from tblpivot1;
select*from tblinfoEnd_Time;

Drop table if exists tblpivot2;

SET @sql = NULL;
SELECT
GROUP_CONCAT(DISTINCT
CONCAT
(
"max(case when odate = """,odate,""" then pr end) ","'",DAY(odate),"'"
)
) INTO @sql
FROM
tblpivot000;
SET @sql = CONCAT("Create table tblpivot2 SELECT jobs, ", @sql,",IFNULL(avg(pr), 0) AS Prom 
FROM tblpivot000
GROUP BY jobs");

SELECT @SQL;
PREPARE stmt FROM @sql;
EXECUTE stmt;
-- DEALLOCATE PREPARE stmt;


select*from tblpivot2;
select*from tblpivot1;



SELECT -- b.Descripcion,b.Meta,b.Cartera,b.Estadío,b.Nombre_Archivo,b.Meta_Cliente,
a.*,c.prom
FROM tblpivot1 as a
left JOIN tbljobsmetacliente as b ON a.jobs =b.jobs
left JOIN tblpivot2 as c ON a.jobs =c.jobs
ORDER BY b.id



Select*from tblMapaCalor